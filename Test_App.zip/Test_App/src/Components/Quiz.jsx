import React, { useState, useRef } from 'react';
import './Quiz.css';
import { data } from '../assets/data';
console.log(data); // Debugging


const Quiz = () => {
    let [index, setIndex] = useState(0);
    let [question, setQuestion] = useState(data[index]);
    let [lock, setLock] = useState(false);
    let [score, setScore] = useState(0);
    let [result, setResult] = useState(false);

    let Option1 = useRef(null);
    let Option2 = useRef(null);

    let option_array = [Option1, Option2];

    const checkAns = (e, ans) => {
        if (lock === false) {
            if (ans === question.ans) {
                e.target.classList.add("red");
                setLock(true);
                setScore(prev => prev + 1);
            } else {
                e.target.classList.add("green");
                setLock(true);
                option_array[question.ans - 1].current.classList.add("green");
            }
        }
    };

    const next = () => {
        if (lock === true) {
            if (index === data.length - 1) {
                setResult(true);
                return; // Correct placement of return statement
            }

            setIndex(prevIndex => prevIndex + 1); // Increment index correctly
            setQuestion(data[index]);
            setLock(false);

            option_array.forEach(option => {
                if (option.current) {
                    option.current.classList.remove("green");
                    option.current.classList.remove("red");
                }
            });
        }
    };

    const reset = () => {
        setIndex(0);
        setQuestion(data[0]);
        setScore(0);
        setLock(false);
        setResult(false);
    };

    return (
        <div className='container'>
            <h1>Test</h1>
            <hr />
            {result ? (
                <>
                    <h2>You Scored {score} out of {data.length}</h2>
                    <button onClick={reset}>Reset</button>
                </>
            ) : (
                <>
                    <h2>{index + 1}. {question.question}</h2>
                    <ul>
                        <li ref={Option1} onClick={(e) => { checkAns(e, 1); }}>{question.option1}</li>
                        <li ref={Option2} onClick={(e) => { checkAns(e, 2); }}>{question.option2}</li>
                    </ul>
                    <button onClick={next}>Submit</button>
                    <div className="index">{index + 1} of {data.length} questions</div>
                </>
            )}
        </div>
    );
};

export default Quiz;
