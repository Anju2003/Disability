export const data = [
    {
      question: "Does the child struggle to learn the alphabet or recognize letters?",
      option1: "YES",
      option2: "NO",
      ans: 1,
    },
    {
      question: "Is it difficult to pronounce unfamiliar words?",
      option1: "YES",
      option2: "NO",
      ans: 1,
    },
    {
      question: "Does the child have difficulty rhyming words (e.g., cat, hat, bat)",
      option1: "YES",
      option2: "NO",
      ans: 1,
    },
    {
      question: " Does the child frequently guess words instead of reading them?",
      option1: "YES",
      option2: "NO",
      ans: 1,
    },
    {
      question: "Does the child have trouble sounding out words when reading?",
      option1: "YES",
      option2: "NO",
      ans: 1,
    },
  ];